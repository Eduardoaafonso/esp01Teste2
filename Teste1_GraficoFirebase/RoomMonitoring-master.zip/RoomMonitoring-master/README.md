# RoomMonitoring
Basic room monitoring using ESP32 with Firebase
